export type MessageStatus = "queued" | "sending" | "delivered" | "read" | "failed";

export const messageTypes = [
  {
    id: "report-card",
    label: "Report Card",
    hint: "Marks, grade and remarks per student",
    icon: "GraduationCap",
  },
  { id: "notice", label: "Notice", hint: "Circulars and announcements", icon: "Megaphone" },
  { id: "homework", label: "Homework", hint: "Daily or weekly assignments", icon: "BookOpen" },
  { id: "attendance", label: "Attendance", hint: "Absent and late alerts", icon: "CalendarCheck" },
  { id: "fee-reminder", label: "Fee Reminder", hint: "Dues, deadlines and receipts", icon: "Receipt" },
  { id: "custom", label: "Custom Message", hint: "Write anything from scratch", icon: "PenLine" },
] as const;

export const audiences = [
  { id: "single", label: "Single Parent", hint: "One recipient", count: 1 },
  { id: "class", label: "Entire Class", hint: "Class VIII — all sections", count: 128 },
  { id: "section", label: "Section", hint: "Class VIII — Section B", count: 42 },
  { id: "selected", label: "Selected Students", hint: "Pick from a list", count: 12 },
] as const;

export const subjects = [
  { id: "tamil", name: "Tamil", total: 100, obtained: 88 },
  { id: "english", name: "English", total: 100, obtained: 76 },
  { id: "maths", name: "Mathematics", total: 100, obtained: 94 },
  { id: "science", name: "Science", total: 100, obtained: 81 },
  { id: "social", name: "Social Science", total: 100, obtained: 69 },
];

export const recentMessages: {
  id: string;
  title: string;
  audience: string;
  status: MessageStatus;
  recipients: number;
  sentAt: string;
  teacher: string;
  template: string;
  klass: string;
}[] = [
  {
    id: "MSG-2914",
    title: "Term II Report Card",
    audience: "Class VIII-B",
    status: "delivered",
    recipients: 42,
    sentAt: "Today, 9:12 AM",
    teacher: "Anitha R.",
    template: "Report Card",
    klass: "VIII-B",
  },
  {
    id: "MSG-2913",
    title: "Annual Day Rehearsal Notice",
    audience: "Class VI — all sections",
    status: "read",
    recipients: 118,
    sentAt: "Today, 8:40 AM",
    teacher: "Karthik S.",
    template: "Circular",
    klass: "VI",
  },
  {
    id: "MSG-2912",
    title: "Maths Homework — Chapter 7",
    audience: "Class IX-A",
    status: "sending",
    recipients: 38,
    sentAt: "Today, 8:05 AM",
    teacher: "Divya P.",
    template: "Homework",
    klass: "IX-A",
  },
  {
    id: "MSG-2911",
    title: "Attendance Alert",
    audience: "6 parents",
    status: "failed",
    recipients: 6,
    sentAt: "Yesterday, 4:20 PM",
    teacher: "Anitha R.",
    template: "Attendance",
    klass: "VII-C",
  },
  {
    id: "MSG-2910",
    title: "Term Fee — Final Reminder",
    audience: "Class X — pending dues",
    status: "delivered",
    recipients: 27,
    sentAt: "Yesterday, 1:02 PM",
    teacher: "Office",
    template: "Fee Reminder",
    klass: "X",
  },
  {
    id: "MSG-2909",
    title: "Holiday — Local Election",
    audience: "Whole school",
    status: "queued",
    recipients: 1420,
    sentAt: "Yesterday, 11:15 AM",
    teacher: "Principal",
    template: "Holiday Notice",
    klass: "All",
  },
];

export const templates = [
  { name: "Report Card", uses: 412, tone: "Academic", body: "Dear Parent, please find the Term II performance summary of {{student}} — Total {{total}}, Percentage {{percent}}%, Grade {{grade}}." },
  { name: "Homework", uses: 908, tone: "Daily", body: "Homework for {{class}} on {{date}}: {{subject}} — {{work}}. Kindly ensure completion." },
  { name: "Attendance", uses: 341, tone: "Alert", body: "Dear Parent, {{student}} was marked absent for {{date}}. Please inform the class teacher." },
  { name: "Fee Reminder", uses: 265, tone: "Billing", body: "Dear Parent, {{amount}} towards Term {{term}} fee is pending for {{student}}. Last date: {{due}}." },
  { name: "Holiday Notice", uses: 96, tone: "Announcement", body: "The school will remain closed on {{date}} on account of {{reason}}. Classes resume {{resume}}." },
  { name: "Exam Notice", uses: 174, tone: "Academic", body: "{{exam}} begins on {{date}}. Timetable is attached. Kindly help {{student}} prepare." },
  { name: "Circular", uses: 132, tone: "Announcement", body: "Circular {{ref}}: {{summary}}. For queries contact the school office." },
  { name: "Birthday Wishes", uses: 588, tone: "Warm", body: "Warm birthday wishes to {{student}} from all of us at {{school}}!" },
  { name: "Custom Template", uses: 0, tone: "Blank", body: "Start from an empty canvas and design your own message." },
];

export const creditPackages = [
  { credits: 100, price: "₹ 250", per: "₹ 2.50", savings: null, badge: null },
  { credits: 500, price: "₹ 1,150", per: "₹ 2.30", savings: "Save 8%", badge: null },
  { credits: 1000, price: "₹ 2,100", per: "₹ 2.10", savings: "Save 16%", badge: "Most popular" },
  { credits: 5000, price: "₹ 9,500", per: "₹ 1.90", savings: "Save 24%", badge: null },
  { credits: 10000, price: "₹ 17,000", per: "₹ 1.70", savings: "Save 32%", badge: "Best value" },
];

export const billingHistory = [
  { id: "INV-10428", date: "12 Jul 2026", item: "5,000 credits", amount: "₹ 9,500", status: "Paid" },
  { id: "INV-10391", date: "08 Jun 2026", item: "Suite Pro — monthly", amount: "₹ 4,999", status: "Paid" },
  { id: "INV-10355", date: "12 May 2026", item: "1,000 credits", amount: "₹ 2,100", status: "Paid" },
  { id: "INV-10322", date: "08 May 2026", item: "Suite Pro — monthly", amount: "₹ 4,999", status: "Paid" },
];

export const classes = [
  { name: "Class VI", sections: ["A", "B", "C"], parents: 118 },
  { name: "Class VII", sections: ["A", "B", "C"], parents: 124 },
  { name: "Class VIII", sections: ["A", "B", "C"], parents: 128 },
  { name: "Class IX", sections: ["A", "B"], parents: 82 },
  { name: "Class X", sections: ["A", "B"], parents: 79 },
];

export const parents = [
  { name: "Meenakshi Sundaram", student: "Aarav S.", klass: "VIII-B", phone: "+91 98•••• 4412" },
  { name: "Rekha Prasad", student: "Diya P.", klass: "IX-A", phone: "+91 90•••• 1188" },
  { name: "Joseph Antony", student: "Neil A.", klass: "VI-C", phone: "+91 99•••• 7723" },
  { name: "Fatima Rizwan", student: "Zoya R.", klass: "X-A", phone: "+91 87•••• 3390" },
  { name: "Ganesh Iyer", student: "Ishan I.", klass: "VII-B", phone: "+91 96•••• 2205" },
  { name: "Lakshmi Narayan", student: "Tara N.", klass: "VIII-A", phone: "+91 89•••• 6641" },
];

export function gradeFor(percent: number) {
  if (percent >= 90) return "A+";
  if (percent >= 80) return "A";
  if (percent >= 70) return "B+";
  if (percent >= 60) return "B";
  if (percent >= 50) return "C";
  if (percent >= 35) return "D";
  return "E";
}
