import { useCallback, useEffect, useState } from "react";

export type SchoolClass = {
  id: string;
  name: string;
  sections: string[];
  subjects: string[];
};

const STORAGE_KEY = "eddesk.classes.v1";

export const defaultClasses: SchoolClass[] = [
  {
    id: "cls-8",
    name: "8 TH STD",
    sections: ["A", "B", "C"],
    subjects: ["Tamil", "English", "Mathematics", "Science", "Social Science"],
  },
  {
    id: "cls-9",
    name: "9 TH STD",
    sections: ["A", "B"],
    subjects: ["Tamil", "English", "Mathematics", "Science", "Social Science"],
  },
  {
    id: "cls-plus2",
    name: "+2",
    sections: ["A"],
    subjects: ["Tamil", "English", "Physics", "Chemistry", "Maths", "Computer Science"],
  },
];

let cache: SchoolClass[] | null = null;
const listeners = new Set<(value: SchoolClass[]) => void>();

function read(): SchoolClass[] {
  if (cache) return cache;
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as SchoolClass[];
        if (Array.isArray(parsed) && parsed.length) {
          cache = parsed;
          return cache;
        }
      }
    } catch {
      /* ignore malformed storage */
    }
  }
  cache = defaultClasses;
  return cache;
}

function write(next: SchoolClass[]) {
  cache = next;
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore quota errors */
    }
  }
  listeners.forEach((l) => l(next));
}

export function newId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}

/** Shared, persisted list of classes with their sections and subjects. */
export function useClasses() {
  const [classes, setClasses] = useState<SchoolClass[]>(defaultClasses);

  useEffect(() => {
    setClasses(read());
    const listener = (value: SchoolClass[]) => setClasses(value);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  const update = useCallback((updater: (prev: SchoolClass[]) => SchoolClass[]) => {
    write(updater(read()));
  }, []);

  return { classes, update };
}
