import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Search,
  ChevronDown,
  X,
  RotateCcw,
  Check,
  Clock,
  Send,
  Eye,
  AlertTriangle,
} from "lucide-react";
import { PageHeader, Panel, StatusChip } from "@/components/ui-kit";
import { WhatsAppPreview } from "@/components/whatsapp-preview";
import { recentMessages } from "@/lib/mock-data";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Message History — EdDesk Communication Suite" },
      {
        name: "description",
        content:
          "Track every message sent to parents with delivery timelines, status filters and one-click retry.",
      },
      { property: "og:title", content: "Message History — EdDesk Communication Suite" },
      { property: "og:description", content: "Delivery status, timelines and retries in one place." },
    ],
  }),
  component: HistoryPage,
});

const filters = ["Date", "Class", "Status", "Template", "Teacher"];

function HistoryPage() {
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  const rows = useMemo(
    () =>
      recentMessages.filter((m) =>
        `${m.title} ${m.audience} ${m.teacher} ${m.template}`.toLowerCase().includes(query.toLowerCase()),
      ),
    [query],
  );

  const active = recentMessages.find((m) => m.id === openId) ?? null;

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="History"
        title="Message history"
        description="Every send, with delivery state per recipient. Click any row for the full timeline."
      />

      <Panel className="p-0">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-border p-5">
          <label className="flex min-w-0 items-center gap-2.5 rounded-xl border border-border bg-muted/60 px-3.5 py-2.5 transition-colors focus-within:border-primary/40 focus-within:bg-background">
            <Search className="size-4 shrink-0 text-muted-foreground" strokeWidth={1.9} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by title, class or teacher"
              className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </label>
          <div className="hidden shrink-0 flex-wrap gap-2 md:flex">
            {filters.map((f) => (
              <button
                key={f}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
              >
                {f}
                <ChevronDown className="size-3.5" />
              </button>
            ))}
          </div>
        </div>

        <div className="hidden grid-cols-[minmax(0,2.2fr)_minmax(0,1fr)_auto_auto_auto] gap-4 px-5 py-3 text-eyebrow md:grid">
          <span>Message</span>
          <span>Class</span>
          <span className="text-right">Recipients</span>
          <span>Status</span>
          <span>Sent</span>
        </div>

        <ul className="divide-y divide-border">
          {rows.map((m) => (
            <li key={m.id}>
              <button
                onClick={() => setOpenId(m.id)}
                className="grid w-full grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 text-left transition-colors hover:bg-accent/60 md:grid-cols-[minmax(0,2.2fr)_minmax(0,1fr)_auto_auto_auto]"
              >
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium">{m.title}</span>
                  <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                    {m.id} · {m.template} · {m.teacher}
                  </span>
                </span>
                <span className="hidden truncate text-sm text-muted-foreground md:block">{m.klass}</span>
                <span className="hidden text-right text-sm tabular-nums md:block">{m.recipients}</span>
                <StatusChip status={m.status} />
                <span className="hidden whitespace-nowrap text-xs text-muted-foreground md:block">
                  {m.sentAt}
                </span>
              </button>
            </li>
          ))}
        </ul>

        {rows.length === 0 && (
          <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
            <span className="grid size-12 place-items-center rounded-2xl bg-muted text-muted-foreground">
              <Search className="size-5" strokeWidth={1.8} />
            </span>
            <p className="font-display text-base font-semibold">No messages match “{query}”</p>
            <p className="max-w-sm text-sm text-muted-foreground">
              Try a class name like “VIII-B”, a teacher, or clear the search to see everything.
            </p>
            <button
              onClick={() => setQuery("")}
              className="mt-1 rounded-xl border border-border px-4 py-2 text-sm font-medium transition-colors hover:bg-accent"
            >
              Clear search
            </button>
          </div>
        )}
      </Panel>

      {active && (
        <div className="fixed inset-0 z-50 flex justify-end bg-foreground/20 backdrop-blur-sm">
          <button className="flex-1" aria-label="Close" onClick={() => setOpenId(null)} />
          <aside className="h-full w-full max-w-xl overflow-y-auto bg-background p-7 shadow-pop sm:rounded-l-3xl">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4">
              <div className="min-w-0">
                <p className="text-eyebrow">{active.id}</p>
                <h2 className="mt-1 font-display text-xl font-semibold">{active.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  {active.audience} · {active.recipients} recipients
                </p>
              </div>
              <button
                onClick={() => setOpenId(null)}
                className="grid size-9 shrink-0 place-items-center rounded-full border border-border transition-colors hover:bg-accent"
              >
                <X className="size-4" strokeWidth={2} />
              </button>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              <StatusChip status={active.status} />
              <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                {active.template}
              </span>
              <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                {active.teacher}
              </span>
            </div>

            <h3 className="mt-8 text-eyebrow">Delivery timeline</h3>
            <ol className="mt-3 space-y-0">
              {[
                { icon: Clock, label: "Queued", time: active.sentAt, done: true },
                { icon: Send, label: "Sent to WhatsApp", time: "+2s", done: true },
                {
                  icon: Check,
                  label: "Delivered",
                  time: "+6s",
                  done: active.status !== "queued" && active.status !== "failed",
                },
                { icon: Eye, label: "Read by parent", time: "+3m", done: active.status === "read" },
                {
                  icon: AlertTriangle,
                  label: "Failed — invalid number",
                  time: "+8s",
                  done: active.status === "failed",
                  danger: true,
                },
              ]
                .filter((s) => !(s.danger && active.status !== "failed"))
                .map((s) => (
                  <li key={s.label} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <span
                        className={[
                          "grid size-8 shrink-0 place-items-center rounded-full",
                          s.danger
                            ? "bg-destructive/10 text-destructive"
                            : s.done
                              ? "bg-success/10 text-success"
                              : "bg-muted text-muted-foreground",
                        ].join(" ")}
                      >
                        <s.icon className="size-4" strokeWidth={2} />
                      </span>
                      <span className="my-1 w-px flex-1 bg-border last:hidden" />
                    </div>
                    <div className="min-w-0 pb-5">
                      <p className={`text-sm font-medium ${s.done ? "" : "text-muted-foreground"}`}>
                        {s.label}
                      </p>
                      <p className="text-xs text-muted-foreground">{s.done ? s.time : "pending"}</p>
                    </div>
                  </li>
                ))}
            </ol>

            <h3 className="mt-4 text-eyebrow">Actual WhatsApp message</h3>
            <div className="mt-3">
              <WhatsAppPreview
                recipient="Meenakshi Sundaram"
                time={active.sentAt.split(", ")[1] ?? "9:12 AM"}
                lines={[
                  "Sunrise Vidyalaya",
                  "",
                  `${active.title}`,
                  `Class ${active.klass}`,
                  "",
                  "Kindly acknowledge this message. For queries contact the school office.",
                ]}
              />
            </div>

            {active.status === "failed" && (
              <button className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3.5 text-sm font-medium text-primary-foreground transition-transform hover:-translate-y-0.5">
                <RotateCcw className="size-4" strokeWidth={2.2} />
                Retry 6 failed deliveries
              </button>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
