import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { GraduationCap, Plus, Trash2, Layers, BookOpen, X, Check } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/ui-kit";
import { newId, useClasses, type SchoolClass } from "@/lib/classes-store";

export const Route = createFileRoute("/classes")({
  head: () => ({
    meta: [
      { title: "Manage Classes & Subjects — EdDesk Communication Suite" },
      {
        name: "description",
        content:
          "Configure standards, sections and subject lists once, so report card marks entry is auto-filled for every class.",
      },
      { property: "og:title", content: "Manage Classes & Subjects — EdDesk" },
      {
        property: "og:description",
        content: "Set up standards, sections and subjects that auto-fill report card marks entry.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ManageClasses,
});

function ManageClasses() {
  const { classes, update } = useClasses();

  const addClass = () => {
    const cls: SchoolClass = { id: newId("cls"), name: "New Standard", sections: [], subjects: [] };
    update((prev) => [...prev, cls]);
    toast.success("Class added", { description: "Rename it and add sections and subjects." });
  };

  const patchClass = (id: string, patch: Partial<SchoolClass>) =>
    update((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));

  const removeClass = (id: string) => {
    update((prev) => prev.filter((c) => c.id !== id));
    toast.success("Class removed");
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Academic"
        title="Classes & Subjects"
        description="Configure standards, sections and subject lists. Report card marks entry fills in automatically from here."
        action={
          <button
            onClick={addClass}
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-card transition-transform hover:-translate-y-0.5"
          >
            <Plus className="size-4" strokeWidth={2.4} />
            Add class / standard
          </button>
        }
      />

      <div className="space-y-5">
        {classes.map((cls, index) => (
          <section key={cls.id} className="surface p-6">
            <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4">
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary-soft font-display text-sm font-semibold text-primary">
                {index + 1}
              </span>
              <div className="min-w-0">
                <input
                  value={cls.name}
                  onChange={(e) => patchClass(cls.id, { name: e.target.value })}
                  className="w-full rounded-lg border border-transparent bg-transparent px-2 py-1 font-display text-lg font-semibold outline-none focus:border-border focus:bg-background"
                />
                <p className="px-2 text-xs text-muted-foreground">
                  {cls.sections.length} sections · {cls.subjects.length} subjects
                </p>
              </div>
              <button
                onClick={() => removeClass(cls.id)}
                aria-label={`Delete ${cls.name}`}
                className="grid size-9 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
              >
                <Trash2 className="size-4" strokeWidth={1.9} />
              </button>
            </div>

            <div className="mt-5 grid gap-6 border-t border-border pt-5 lg:grid-cols-2">
              <ChipEditor
                icon={Layers}
                label={`Sections (${cls.sections.length})`}
                hint="Optional"
                placeholder="e.g. A"
                values={cls.sections}
                onChange={(sections) => patchClass(cls.id, { sections })}
              />
              <ListEditor
                icon={BookOpen}
                label={`Subjects (${cls.subjects.length})`}
                hint="Auto-filled in marks entry"
                placeholder="e.g. Mathematics"
                values={cls.subjects}
                onChange={(subjects) => patchClass(cls.id, { subjects })}
              />
            </div>
          </section>
        ))}

        {classes.length === 0 ? (
          <div className="surface grid place-items-center gap-3 p-12 text-center">
            <span className="grid size-11 place-items-center rounded-xl bg-primary-soft text-primary">
              <GraduationCap className="size-[22px]" strokeWidth={1.9} />
            </span>
            <p className="text-sm text-muted-foreground">
              No classes yet — add your first standard to get started.
            </p>
          </div>
        ) : null}
      </div>
    </div>
  );
}

type EditorProps = {
  icon: typeof Layers;
  label: string;
  hint?: string | undefined;
  placeholder: string;
  values: string[];
  onChange: (values: string[]) => void;
};

function useAdder(values: string[], onChange: (values: string[]) => void) {
  const [draft, setDraft] = useState("");
  const commit = () => {
    const value = draft.trim();
    if (!value) return;
    onChange([...values, value]);
    setDraft("");
  };
  return { draft, setDraft, commit };
}

function EditorHeader({ icon: Icon, label, hint }: Pick<EditorProps, "icon" | "label" | "hint">) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="size-4 text-primary" strokeWidth={2} />
      <p className="text-eyebrow">{label}</p>
      {hint ? <span className="text-xs text-muted-foreground">· {hint}</span> : null}
    </div>
  );
}

function AddRow({
  draft,
  setDraft,
  commit,
  placeholder,
}: {
  draft: string;
  setDraft: (v: string) => void;
  commit: () => void;
  placeholder: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <input
        value={draft}
        placeholder={placeholder}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            commit();
          }
        }}
        className="min-w-0 flex-1 rounded-xl border border-border bg-muted/50 px-3.5 py-2 text-sm outline-none transition-colors focus:border-primary/40 focus:bg-background"
      />
      <button
        onClick={commit}
        className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-medium text-primary transition-colors hover:bg-primary-soft"
      >
        <Check className="size-3.5" strokeWidth={2.4} />
        Add
      </button>
    </div>
  );
}

function ChipEditor({ icon, label, hint, placeholder, values, onChange }: EditorProps) {
  const { draft, setDraft, commit } = useAdder(values, onChange);
  return (
    <div className="space-y-3">
      <EditorHeader icon={icon} label={label} hint={hint} />
      <div className="flex flex-wrap gap-2">
        {values.map((value, i) => (
          <span
            key={`${value}-${i}`}
            className="inline-flex items-center gap-2 rounded-lg bg-muted px-3 py-1.5 text-sm font-medium"
          >
            {value}
            <button
              onClick={() => onChange(values.filter((_, j) => j !== i))}
              aria-label={`Remove ${value}`}
              className="text-muted-foreground transition-colors hover:text-destructive"
            >
              <X className="size-3.5" strokeWidth={2.4} />
            </button>
          </span>
        ))}
        {values.length === 0 ? (
          <span className="text-xs text-muted-foreground">No sections added.</span>
        ) : null}
      </div>
      <AddRow draft={draft} setDraft={setDraft} commit={commit} placeholder={placeholder} />
    </div>
  );
}

function ListEditor({ icon, label, hint, placeholder, values, onChange }: EditorProps) {
  const { draft, setDraft, commit } = useAdder(values, onChange);
  return (
    <div className="space-y-3">
      <EditorHeader icon={icon} label={label} hint={hint} />
      <ul className="space-y-2">
        {values.map((value, i) => (
          <li
            key={`${value}-${i}`}
            className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl bg-muted/60 px-3 py-2"
          >
            <span className="text-xs tabular-nums text-muted-foreground">{i + 1}.</span>
            <input
              value={value}
              onChange={(e) => onChange(values.map((v, j) => (j === i ? e.target.value : v)))}
              className="min-w-0 rounded-lg border border-transparent bg-transparent px-1 py-0.5 text-sm font-medium outline-none focus:border-border focus:bg-background"
            />
            <button
              onClick={() => onChange(values.filter((_, j) => j !== i))}
              aria-label={`Remove ${value}`}
              className="text-muted-foreground transition-colors hover:text-destructive"
            >
              <Trash2 className="size-3.5" strokeWidth={1.9} />
            </button>
          </li>
        ))}
        {values.length === 0 ? (
          <li className="text-xs text-muted-foreground">No subjects added.</li>
        ) : null}
      </ul>
      <AddRow draft={draft} setDraft={setDraft} commit={commit} placeholder={placeholder} />
    </div>
  );
}
