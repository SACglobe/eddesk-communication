import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Coins, Plus } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/ui-kit";

export const Route = createFileRoute("/credits")({
  head: () => ({
    meta: [
      { title: "Credits — EdDesk Communication Suite" },
      {
        name: "description",
        content: "See your available report card credits and top up any amount you need.",
      },
      { property: "og:title", content: "Credits — EdDesk Communication Suite" },
      { property: "og:description", content: "Available credits and instant top-up for school messaging." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CreditsPage,
});

const quick = [100, 500, 1000, 5000];
const RATE = 2;

function CreditsPage() {
  const [amount, setAmount] = useState(500);

  return (
    <div className="space-y-10">
      <PageHeader
        eyebrow="Billing"
        title="Credits"
        description="One credit sends one report card. Top up any amount — credits never expire."
      />

      <section className="max-w-2xl space-y-6">
        <div className="surface flex flex-wrap items-center justify-between gap-4 bg-primary-soft/60 px-6 py-5">
          <div>
            <p className="text-eyebrow">Available credits</p>
            <p className="font-display text-4xl font-semibold tabular-nums">3,480</p>
          </div>
          <p className="text-sm text-muted-foreground">= 3,480 report cards you can send</p>
        </div>

        <div className="surface p-7">

          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl bg-primary-soft text-primary">
              <Coins className="size-5" strokeWidth={1.9} />
            </span>
            <div>
              <h2 className="font-display text-lg font-semibold">Top up credits</h2>
              <p className="text-sm text-muted-foreground">₹ {RATE.toFixed(2)} per credit</p>
            </div>
          </div>

          <label className="mt-6 block">
            <span className="text-eyebrow">Number of credits</span>
            <span className="mt-1 flex items-center gap-2 rounded-xl border border-border bg-muted/50 px-4 py-3 transition-colors focus-within:border-primary/40 focus-within:bg-background">
              <input
                type="number"
                min={1}
                value={amount}
                onChange={(e) => setAmount(Math.max(0, Number(e.target.value) || 0))}
                className="min-w-0 flex-1 bg-transparent font-display text-2xl font-semibold tabular-nums outline-none"
              />
              <span className="shrink-0 text-sm text-muted-foreground">credits</span>
            </span>
          </label>

          <div className="mt-3 flex flex-wrap gap-2">
            {quick.map((q) => (
              <button
                key={q}
                onClick={() => setAmount(q)}
                className={[
                  "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors",
                  amount === q
                    ? "border-primary/50 bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
                ].join(" ")}
              >
                +{q.toLocaleString()}
              </button>
            ))}
          </div>

          <div className="mt-6 flex items-baseline justify-between border-t border-border pt-5">
            <p className="text-sm text-muted-foreground">Amount payable</p>
            <p className="font-display text-2xl font-semibold tabular-nums">
              ₹ {(amount * RATE).toLocaleString("en-IN")}
            </p>
          </div>

          <button
            disabled={amount < 1}
            onClick={() =>
              toast.success(`${amount.toLocaleString()} credits added`, {
                description: `₹ ${(amount * RATE).toLocaleString("en-IN")} charged · new balance ${(
                  3480 + amount
                ).toLocaleString()}`,
              })
            }
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3.5 text-sm font-medium text-primary-foreground shadow-card transition-transform hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-45"
          >
            <Plus className="size-4" strokeWidth={2.4} />
            Top up {amount > 0 ? amount.toLocaleString() : ""} credits
          </button>
        </div>
      </section>
    </div>
  );
}
