import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Send as SendIcon, Coins } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, Panel } from "@/components/ui-kit";
import { WhatsAppPreview } from "@/components/whatsapp-preview";
import { gradeFor } from "@/lib/mock-data";
import { useClasses } from "@/lib/classes-store";


export const Route = createFileRoute("/send")({
  head: () => ({
    meta: [
      { title: "Send Report Card — EdDesk Communication Suite" },
      {
        name: "description",
        content:
          "Enter student details and marks, then send a formatted report card to the parent on WhatsApp with a live preview.",
      },
      { property: "og:title", content: "Send Report Card — EdDesk Communication Suite" },
      {
        property: "og:description",
        content: "Marks entry with automatic totals, grade and a live WhatsApp preview.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SendReportCard,
});

type Subject = { id: string; name: string; total: number; obtained: number };

function SendReportCard() {
  const { classes } = useClasses();
  const schoolName = "Sunrise International";
  const schoolPhone = "9994026550";
  const parent = "Meenakshi Sundaram";
  const [phone, setPhone] = useState("9876504412");
  const [student, setStudent] = useState("Aarav Sundaram");
  const [classId, setClassId] = useState("");
  const [section, setSection] = useState("");
  const [exam, setExam] = useState("Term II Examination");
  const [marks, setMarks] = useState<Subject[]>([]);
  const [remarks, setRemarks] = useState(
    "Aarav has shown steady improvement in Mathematics. A little more attention to Social Science will help.",
  );

  const selectedClass = classes.find((c) => c.id === classId);

  useEffect(() => {
    if (!classId && classes.length) setClassId(classes[0]!.id);
  }, [classes, classId]);

  // Selecting a class auto-fills its configured subjects into marks entry.
  useEffect(() => {
    const cls = classes.find((c) => c.id === classId);
    if (!cls) return;
    setSection(cls.sections[0] ?? "");
    setMarks(
      cls.subjects.map((name, i) => ({
        id: `${cls.id}-${i}-${name}`,
        name,
        total: 100,
        obtained: 0,
      })),
    );
  }, [classId, classes]);

  const klass = selectedClass
    ? `${selectedClass.name}${section ? ` - SECTION ${section}` : ""}`
    : "";


  const totals = useMemo(() => {
    const total = marks.reduce((s, m) => s + m.total, 0);
    const obtained = marks.reduce((s, m) => s + m.obtained, 0);
    const percent = total ? Math.round((obtained / total) * 1000) / 10 : 0;
    return { total, obtained, percent, grade: gradeFor(percent), pass: percent >= 35 };
  }, [marks]);

  const formattedSchoolPhone =
    schoolPhone.replace(/\D/g, "").length === 10
      ? `+91 ${schoolPhone.replace(/\D/g, "").slice(0, 5)} ${schoolPhone.replace(/\D/g, "").slice(5)}`
      : schoolPhone;

  const previewLines = [
    `🎓 *${schoolName || "School Name"} (${formattedSchoolPhone})* 🎓`,
    "",
    `Dear Parent, the report card for *${exam || "—"}* exam has been published.`,
    "",
    `👤 *Name:* ${student || "—"}`,
    `🏫 *Class & Sec:* ${klass || "—"}`,
    "",
    "*--- Marks ---*",
    ...marks.filter((m) => m.name.trim()).map((m) => `${m.name}: ${m.obtained} / ${m.total}`),
    "",
    `📊 *Total:* ${totals.obtained} / ${totals.total}`,
    `📈 *Percentage:* ${totals.percent.toFixed(2)}%`,
    "",
    "*--- Remarks ---*",
    ...(remarks.trim() ? [remarks] : ["—"]),
    `Contact us on ${formattedSchoolPhone}`,
    "",
    "If you have any questions regarding your child's report card, please contact the school. Thank you!",
  ];

  const canSend = phone.replace(/\D/g, "").length === 10 && student.trim().length > 0;

  const updateSubject = (index: number, patch: Partial<Subject>) => {
    setMarks((prev) => prev.map((m, i) => (i === index ? { ...m, ...patch } : m)));
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Report card"
        title="Send a report card"
        description="Fill in the details below. The WhatsApp preview updates as you type."
      />

      <div className="grid gap-8 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,420px)]">
        <div className="space-y-5">
          <Panel>
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField label="Student name" value={student} onChange={setStudent} placeholder="e.g. Aarav Sundaram" />
              <SelectField
                label="Class / standard"
                value={classId}
                onChange={setClassId}
                options={classes.map((c) => ({ value: c.id, label: c.name }))}
                empty="No classes configured"
              />
              <SelectField
                label="Section"
                value={section}
                onChange={setSection}
                options={(selectedClass?.sections ?? []).map((s) => ({ value: s, label: s }))}
                empty="No sections"
              />

              <PhoneField label="Parent WhatsApp" value={phone} onChange={setPhone} />
              <TextField label="Exam name" value={exam} onChange={setExam} placeholder="e.g. Term II Examination" />
            </div>
          </Panel>

          <Panel
            title="Marks entry"
            hint="Subjects come from the selected class. Totals update automatically."
            action={
              <Link to="/classes" className="text-xs font-medium text-primary hover:underline">
                Manage classes
              </Link>
            }
          >
            {marks.length === 0 ? (
              <p className="rounded-xl bg-muted/60 p-4 text-sm text-muted-foreground">
                No subjects configured for this class.{" "}
                <Link to="/classes" className="font-medium text-primary hover:underline">
                  Add subjects
                </Link>{" "}
                to auto-fill marks entry.
              </p>
            ) : null}
            <div className="overflow-hidden rounded-xl border border-border">

              <table className="w-full text-sm">
                <thead className="bg-muted/60">
                  <tr>
                    <th className="px-4 py-2.5 text-left text-xs font-medium text-muted-foreground">Subject</th>
                    <th className="w-28 px-3 py-2.5 text-right text-xs font-medium text-muted-foreground">Obtained</th>
                    <th className="w-28 px-3 py-2.5 text-right text-xs font-medium text-muted-foreground">Total</th>
                    <th className="w-20 px-3 py-2.5 text-right text-xs font-medium text-muted-foreground">%</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {marks.map((m, i) => {
                    const pct = m.total ? Math.round((m.obtained / m.total) * 1000) / 10 : 0;
                    return (
                      <tr key={m.id} className="hover:bg-muted/30">
                        <td className="px-3 py-2">
                          <input
                            value={m.name}
                            placeholder={`Subject ${i + 1}`}
                            onChange={(e) => updateSubject(i, { name: e.target.value })}
                            className="w-full rounded-lg border border-transparent bg-transparent px-2 py-1.5 text-sm font-medium outline-none focus:border-border focus:bg-background"
                          />
                        </td>
                        <td className="px-2 py-2">
                          <input
                            type="number"
                            min={0}
                            max={m.total}
                            value={m.obtained}
                            onChange={(e) => updateSubject(i, { obtained: Math.min(Number(e.target.value) || 0, m.total) })}
                            className="w-full rounded-lg border border-transparent bg-transparent px-2 py-1.5 text-right text-sm tabular-nums outline-none focus:border-border focus:bg-background"
                          />
                        </td>
                        <td className="px-2 py-2">
                          <input
                            type="number"
                            min={1}
                            value={m.total}
                            onChange={(e) => updateSubject(i, { total: Number(e.target.value) || 0 })}
                            className="w-full rounded-lg border border-transparent bg-transparent px-2 py-1.5 text-right text-sm tabular-nums outline-none focus:border-border focus:bg-background"
                          />
                        </td>
                        <td className="px-3 py-2 text-right text-xs tabular-nums text-muted-foreground">{pct}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-5 grid gap-3 rounded-xl bg-primary-soft/60 p-4 sm:grid-cols-2">
              <Summary label="Total" value={`${totals.obtained} / ${totals.total}`} />
              <Summary label="Percentage" value={`${totals.percent}%`} />
            </div>
          </Panel>

          <Panel title="Remarks" hint="Optional — added at the end of the message.">
            <textarea
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              rows={3}
              placeholder="Write a short note for the parent..."
              className="w-full resize-none rounded-xl border border-border bg-muted/50 p-4 text-sm outline-none transition-colors focus:border-primary/40 focus:bg-background"
            />
          </Panel>
        </div>

        <div className="space-y-4 xl:sticky xl:top-24 xl:self-start">
          <p className="text-eyebrow">Live WhatsApp preview</p>
          <WhatsAppPreview lines={previewLines} recipient={parent || "Parent"} />

          <div className="surface p-5">
            <div className="flex items-center justify-between gap-4 rounded-xl bg-muted/50 p-4">
              <span className="flex items-center gap-2 text-sm text-muted-foreground">
                <Coins className="size-4 text-primary" strokeWidth={2} />
                1 credit per report card
              </span>
              <span className="text-sm font-medium tabular-nums">3,480 credits left</span>
            </div>

            <button
              disabled={!canSend}
              onClick={() =>
                toast.success(`Report card sent to ${parent || "the parent"}`, {
                  description: `${student} · ${exam} · ${totals.percent}% (${totals.grade})`,
                })
              }
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-whatsapp px-5 py-3.5 text-sm font-semibold text-primary-foreground shadow-card transition-transform hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-45"
            >
              <SendIcon className="size-4" strokeWidth={2.2} />
              Send WhatsApp message
            </button>

            <p className="mt-3 text-center text-xs text-muted-foreground">
              {canSend
                ? "Delivery is tracked in History."
                : "Add a 10-digit number and a student name to send."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="text-eyebrow">{label}</span>
      <input
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1.5 w-full rounded-xl border border-border bg-muted/50 px-3.5 py-2.5 text-sm font-medium outline-none transition-colors focus:border-primary/40 focus:bg-background"
      />
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
  empty,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  empty: string;
}) {
  return (
    <label className="block">
      <span className="text-eyebrow">{label}</span>
      <select
        value={value}
        disabled={options.length === 0}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1.5 w-full rounded-xl border border-border bg-muted/50 px-3.5 py-2.5 text-sm font-medium outline-none transition-colors focus:border-primary/40 focus:bg-background disabled:opacity-60"
      >
        {options.length === 0 ? <option value="">{empty}</option> : null}
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}


function PhoneField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="text-eyebrow">{label}</span>
      <span className="mt-1.5 flex items-center gap-2 rounded-xl border border-border bg-muted/50 px-3.5 py-2.5 transition-colors focus-within:border-primary/40 focus-within:bg-background">
        <span className="shrink-0 text-sm text-muted-foreground">+91</span>
        <input
          value={value}
          placeholder="10-digit mobile number"
          onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, 10))}
          className="min-w-0 flex-1 bg-transparent text-sm font-medium outline-none placeholder:font-normal placeholder:text-muted-foreground"
        />
      </span>
    </label>
  );
}

function Summary({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: string;
  tone?: "default" | "success" | "danger";
}) {
  return (
    <div>
      <p className="text-eyebrow">{label}</p>
      <p
        className={[
          "mt-1 font-display text-lg font-semibold tabular-nums",
          tone === "success" ? "text-success" : tone === "danger" ? "text-destructive" : "",
        ].join(" ")}
      >
        {value}
      </p>
    </div>
  );
}
