import { createFileRoute } from "@tanstack/react-router";
import { Check, Download, Sparkles } from "lucide-react";
import { PageHeader, Panel, Bar } from "@/components/ui-kit";
import { billingHistory } from "@/lib/mock-data";

export const Route = createFileRoute("/subscription")({
  head: () => ({
    meta: [
      { title: "Subscription — EdDesk Communication Suite" },
      {
        name: "description",
        content:
          "Review your plan, renewal date, included features and usage, compare upgrades and download invoices.",
      },
      { property: "og:title", content: "Subscription — EdDesk Communication Suite" },
      { property: "og:description", content: "Clean plan overview with transparent upgrade options." },
    ],
  }),
  component: SubscriptionPage,
});

const plans = [
  {
    name: "Essential",
    price: "₹ 1,999",
    per: "per month",
    blurb: "For single-branch schools sending routine updates.",
    features: ["2,000 credits included", "Report card sending", "2 teacher logins", "Email support"],
    current: false,
  },
  {
    name: "Suite Pro",
    price: "₹ 4,999",
    per: "per month",
    blurb: "Everything a busy school office needs, with report cards.",
    features: [
      "6,000 credits included",
      "Unlimited report cards",
      "25 teacher logins",
      "Report card automation",
      "Delivery analytics",
      "Priority support",
    ],
    current: true,
  },
  {
    name: "District",
    price: "Custom",
    per: "annual",
    blurb: "Multiple campuses under one communication desk.",
    features: [
      "Pooled credits across campuses",
      "Multi-school switcher",
      "Role-based approvals",
      "Dedicated success manager",
    ],
    current: false,
  },
];

function SubscriptionPage() {
  return (
    <div className="space-y-10">
      <PageHeader
        eyebrow="Plan"
        title="Subscription"
        description="You are on Suite Pro. Renewal and included credits are shown below."
        action={
          <button className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-card transition-transform hover:-translate-y-0.5">
            <Sparkles className="size-4" strokeWidth={2.2} />
            Upgrade plan
          </button>
        }
      />

      <section className="grid gap-6 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <div className="surface p-7">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4">
            <div className="min-w-0">
              <p className="text-eyebrow">Current plan</p>
              <h2 className="mt-1 font-display text-2xl font-semibold">Suite Pro</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                ₹ 4,999 per month · renews 08 Sep 2026
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-success/10 px-3 py-1 text-[11px] font-medium text-success">
              Active
            </span>
          </div>

          <div className="mt-7 grid gap-6 sm:grid-cols-2">
            <div>
              <div className="mb-2 flex justify-between text-xs text-muted-foreground">
                <span>Credits used</span>
                <span className="tabular-nums">2,520 / 6,000</span>
              </div>
              <Bar value={42} />
            </div>
            <div>
              <div className="mb-2 flex justify-between text-xs text-muted-foreground">
                <span>Teacher seats</span>
                <span className="tabular-nums">14 / 25</span>
              </div>
              <Bar value={56} />
            </div>
          </div>

          <h3 className="mt-8 text-eyebrow">Included in your plan</h3>
          <ul className="mt-3 grid gap-2.5 sm:grid-cols-2">
            {plans[1]!.features.map((f) => (
              <li key={f} className="flex items-center gap-2.5 text-sm">
                <span className="grid size-5 shrink-0 place-items-center rounded-full bg-success/10 text-success">
                  <Check className="size-3" strokeWidth={3} />
                </span>
                {f}
              </li>
            ))}
          </ul>
        </div>

        <Panel title="Payment method" hint="Charged automatically on renewal">
          <div className="rounded-xl border border-border p-4">
            <p className="text-sm font-medium">HDFC Bank •••• 4412</p>
            <p className="mt-0.5 text-xs text-muted-foreground">Expires 04 / 2029</p>
          </div>
          <button className="mt-3 w-full rounded-xl border border-border py-2.5 text-sm font-medium transition-colors hover:bg-accent">
            Update payment method
          </button>
          <div className="hairline my-6" />
          <p className="text-eyebrow">Next invoice</p>
          <p className="mt-1 font-display text-xl font-semibold tabular-nums">₹ 4,999</p>
          <p className="mt-0.5 text-xs text-muted-foreground">08 Sep 2026 · includes 6,000 credits</p>
        </Panel>
      </section>

      <section className="space-y-4">
        <h2 className="font-display text-lg font-semibold">Upgrade options</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {plans.map((p) => (
            <article
              key={p.name}
              className={[
                "flex flex-col p-6",
                p.current
                  ? "rounded-2xl border border-primary/45 bg-card shadow-lift"
                  : "action-tile",
              ].join(" ")}
            >
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                <h3 className="truncate font-display text-[17px] font-semibold">{p.name}</h3>
                {p.current && (
                  <span className="shrink-0 rounded-full bg-primary px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-primary-foreground">
                    Current
                  </span>
                )}
              </div>
              <p className="mt-3 font-display text-3xl font-semibold tabular-nums">{p.price}</p>
              <p className="text-xs text-muted-foreground">{p.per}</p>
              <p className="mt-3 text-sm text-muted-foreground">{p.blurb}</p>
              <ul className="mt-5 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0 text-primary" strokeWidth={2.4} />
                    <span className="min-w-0">{f}</span>
                  </li>
                ))}
              </ul>
              <button
                disabled={p.current}
                className="mt-6 rounded-xl border border-border py-2.5 text-sm font-medium transition-colors enabled:hover:border-primary/50 enabled:hover:bg-primary enabled:hover:text-primary-foreground disabled:opacity-40"
              >
                {p.current ? "Your plan" : p.name === "District" ? "Talk to sales" : "Choose plan"}
              </button>
            </article>
          ))}
        </div>
      </section>

      <Panel title="Invoices & payment history">
        <ul className="divide-y divide-border">
          {billingHistory.map((b) => (
            <li key={b.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 py-3.5">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{b.id}</p>
                <p className="mt-0.5 truncate text-xs text-muted-foreground">
                  {b.date} · {b.item}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-4">
                <span className="text-sm font-medium tabular-nums">{b.amount}</span>
                <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-medium transition-colors hover:bg-accent">
                  <Download className="size-3.5" strokeWidth={2} />
                  PDF
                </button>
              </div>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
