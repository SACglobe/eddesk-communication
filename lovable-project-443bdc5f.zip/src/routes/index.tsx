import { createFileRoute, Link } from "@tanstack/react-router";
import { GraduationCap, ArrowUpRight, Coins, History as HistoryIcon, Layers } from "lucide-react";
import { Metric, Panel, PageHeader, StatusChip } from "@/components/ui-kit";
import { recentMessages } from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — EdDesk Communication Suite" },
      {
        name: "description",
        content:
          "Your school's report card centre: send formatted report cards to parents on WhatsApp and track every delivery.",
      },
      { property: "og:title", content: "Dashboard — EdDesk Communication Suite" },
      { property: "og:description", content: "Send report cards to parents in three clicks." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const actions = [
  {
    to: "/send" as const,
    label: "Send Report Card",
    hint: "Enter marks, preview and send to the parent",
    icon: GraduationCap,
  },
  {
    to: "/classes" as const,
    label: "Manage Classes",
    hint: "Standards, sections and subjects that auto-fill marks",
    icon: Layers,
  },
  {
    to: "/history" as const,
    label: "Delivery History",
    hint: "Every report card sent, with delivery status",
    icon: HistoryIcon,
  },

  {
    to: "/credits" as const,
    label: "Top up Credits",
    hint: "3,480 credits available — add any amount",
    icon: Coins,
  },
];

function Dashboard() {
  const reportCards = recentMessages.filter((m) => m.template === "Report Card");
  const recent = reportCards.length ? reportCards : recentMessages.slice(0, 4);

  return (
    <div className="space-y-10">
      <PageHeader
        eyebrow="Report card centre"
        title="Good morning, Anitha"
        description="Report cards are the only thing you send from here — enter marks, check the preview, send."
        action={
          <Link
            to="/send"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-card transition-transform hover:-translate-y-0.5"
          >
            New report card
            <ArrowUpRight className="size-4" strokeWidth={2.2} />
          </Link>
        }
      />

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {actions.map((a) => (
          <Link key={a.label} to={a.to} className="action-tile group flex flex-col gap-6 p-6">
            <span className="grid size-11 place-items-center rounded-xl bg-primary-soft text-primary">
              <a.icon className="size-[22px]" strokeWidth={1.9} />
            </span>
            <span>
              <span className="block font-display text-[17px] font-semibold">{a.label}</span>
              <span className="mt-1 block text-sm text-muted-foreground">{a.hint}</span>
            </span>
            <span className="mt-auto inline-flex items-center gap-1.5 text-xs font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100">
              Open
              <ArrowUpRight className="size-3.5" strokeWidth={2.4} />
            </span>
          </Link>
        ))}
      </section>

      <div className="hairline" />

      <section className="space-y-4">
        <h2 className="font-display text-lg font-semibold">Today's activity</h2>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Metric label="Report cards sent today" value="184" sub="Across 6 classes" />
          <Metric label="Credits remaining" value="3,480" sub="1 credit per report card" />
          <Metric label="Delivery success" value="98.4%" sub="Last 7 days" tone="success" />
          <Metric label="Failed deliveries" value="3" sub="Retry available" tone="danger" />
        </div>
      </section>

      <Panel
        title="Recent report cards"
        hint="Latest sends across the school"
        action={
          <Link to="/history" className="text-xs font-medium text-primary hover:underline">
            View history
          </Link>
        }
      >
        <ul className="divide-y divide-border">
          {recent.map((m) => (
            <li key={m.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 py-3.5">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{m.title}</p>
                <p className="mt-0.5 truncate text-xs text-muted-foreground">
                  {m.audience} · {m.recipients} recipients · {m.sentAt}
                </p>
              </div>
              <StatusChip status={m.status} />
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
