import { Link } from "@tanstack/react-router";
import { Bell, ChevronDown, Coins, Search } from "lucide-react";

export function AppHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto grid max-w-[1400px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-6 py-3.5 lg:px-10">
        <label className="flex min-w-0 max-w-md items-center gap-2.5 rounded-xl border border-border bg-muted/60 px-3.5 py-2.5 text-sm transition-colors focus-within:border-primary/40 focus-within:bg-background">
          <Search className="size-4 shrink-0 text-muted-foreground" strokeWidth={1.9} />
          <input
            placeholder="Search students, parents, messages…"
            className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <kbd className="hidden shrink-0 rounded-md border border-border bg-background px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground sm:block">
            ⌘K
          </kbd>
        </label>

        <div className="flex shrink-0 items-center gap-2">
          <Link
            to="/credits"
            className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium transition-colors hover:border-primary/40 sm:flex"
          >
            <Coins className="size-3.5 text-primary" strokeWidth={2} />
            <span className="tabular-nums">3,480</span>
            <span className="text-muted-foreground">credits</span>
          </Link>

          <button className="relative grid size-9 place-items-center rounded-full border border-border bg-card transition-colors hover:bg-accent">
            <Bell className="size-4 text-muted-foreground" strokeWidth={1.9} />
            <span className="absolute right-2 top-2 size-1.5 rounded-full bg-destructive" />
          </button>

          <button className="hidden items-center gap-2 rounded-full border border-border bg-card py-1.5 pl-3 pr-2 text-xs font-medium transition-colors hover:bg-accent md:flex">
            Sunrise Vidyalaya
            <ChevronDown className="size-3.5 text-muted-foreground" />
          </button>

          <button className="flex items-center gap-2 rounded-full border border-border bg-card py-1 pl-1 pr-2.5 transition-colors hover:bg-accent">
            <span className="grid size-7 place-items-center rounded-full bg-primary text-[11px] font-semibold text-primary-foreground">
              AR
            </span>
            <ChevronDown className="size-3.5 text-muted-foreground" />
          </button>
        </div>
      </div>
    </header>
  );
}
