import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Send,
  History,
  Coins,
  BadgeCheck,
  MessageCircle,
  GraduationCap,
} from "lucide-react";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/send", label: "Send Report Card", icon: Send },
  { to: "/classes", label: "Manage Classes", icon: GraduationCap },
  { to: "/history", label: "History", icon: History },
  { to: "/credits", label: "Credits", icon: Coins },
  { to: "/subscription", label: "Subscription", icon: BadgeCheck },
] as const;


export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <aside className="sticky top-0 hidden h-screen w-[264px] shrink-0 flex-col border-r border-sidebar-border bg-sidebar px-4 py-6 lg:flex">
      <Link to="/" className="mb-8 flex items-center gap-3 px-2">
        <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground shadow-card">
          <MessageCircle className="size-5" strokeWidth={2.2} />
        </span>
        <span className="min-w-0">
          <span className="block truncate font-display text-[15px] font-semibold leading-tight">
            EdDesk
          </span>
          <span className="block truncate text-xs text-muted-foreground">
            Communication Suite
          </span>
        </span>
      </Link>

      <p className="px-3 pb-2 text-eyebrow">Communication</p>
      <nav className="flex flex-col gap-0.5">
        {nav.map((item) => {
          const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={[
                "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors",
                active
                  ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
              ].join(" ")}
            >
              <item.icon
                className={[
                  "size-[18px] shrink-0 transition-colors",
                  active ? "text-primary" : "text-muted-foreground group-hover:text-foreground",
                ].join(" ")}
                strokeWidth={1.9}
              />
              <span className="truncate">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto rounded-xl border border-border bg-primary-soft/60 p-4">
        <p className="text-eyebrow">Credits left</p>
        <p className="mt-1 font-display text-2xl font-semibold tabular-nums">3,480</p>
        <p className="mt-1 text-xs text-muted-foreground">1 credit = 1 report card</p>
        <Link
          to="/credits"
          className="mt-3 inline-flex text-xs font-medium text-primary hover:underline"
        >
          Top up credits →
        </Link>
      </div>
    </aside>
  );
}
